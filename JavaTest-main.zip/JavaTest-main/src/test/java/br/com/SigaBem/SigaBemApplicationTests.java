package br.com.SigaBem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SigaBemApplicationTests {

	@Test
	void contextLoads() {
	}

}
